<?php

use Illuminate\Database\Seeder;

class BetsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        // DB::table( 'bets' )->insert([
        //     'user_id'           => 1,
        //     'matches_soccer_id' => 1,
        //     'first_team_goals'  => 2,
        //     'second_team_goals' => 3,
        //     'score'             => null
        // ]);
    }
}
